import Faq from "./Faq";
export default Faq;