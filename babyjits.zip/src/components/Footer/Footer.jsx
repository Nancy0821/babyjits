import "./style.css";

const Footer = () => {
    return (
        <footer>
            Baby Jits (c) 2022. All rights reserved.
        </footer>
    )
}

export default Footer;