import Team from "./Team";
export default Team;